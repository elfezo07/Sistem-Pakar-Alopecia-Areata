<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Sistem Pakar | Diagnosis</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link href="style.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="js/cufon-yui.js"></script>
		<script type="text/javascript" src="js/arial.js"></script>
		<script type="text/javascript" src="js/cuf_run.js"></script>
		<?php include('koneksi.php');?>
		<style>
			input[type=submit]{
				font-family: calibri;
				font-size: 11pt;
				background: red;
				color: white;
				border: red 3px solid;
				border-radius: 5px;}
			a{text-decoration: none;}
			a:hover, input[type=submit]:hover {opacity:0.9;}
			table p{font-family:calibri;font-size:12pt; color:white;}
			.content .mainbar .article{
				margin:30px 150px 50px;
				width:350px;
				height:300px;
				background:url(images/bluebg.png);}
		</style>
	</head>
	
	<body>
		<div class="main">
		  
		  <div class="header">
			<div class="header_resize">
			  <div class="logo">
				<h1><a href="index.php"><span>Sistem Pakar</span>Alopecia Areata</a></h1>
			  </div>
			  <div class="menu_nav">
				<ul>
				  <li><a href="index.php"><span>Beranda</span></a></li>
				  <li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li>
				  <li class="active"><a href="diagnosis.php" style="color:red;"><span><strong/>Diagnosis</span></a></li>
				  <li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li>
				  <li><a href="tentang.php"><span>Tentang</span></a></li>
				</ul>
				<div class="clr"></div>
			  </div>			  
			  <div class="clr"></div>
			  <div class="header_img"><img src="images/medical-animation.png" alt="" width="300" height="125" />
				<h2>Lakukan <span>Diagnosis</span><br/> Sekarang!</h2>
				<p>Diagnosis berbasis web dapat menjadi alternatif pertama Anda sekarang juga!</p></div>
			</div>
		  </div>
		  
		  <div class="clr"></div>
		  <div class="content">
			<div class="content_resize">
			  <div class="mainbar">
				<div class="article">
				  <h2  align="center"><span>Halaman</span> Diagnosis</h2>
				  <div class="clr"></div>
					<!--DISINI FORM-->
					<form action="diagnosis1.php" method="post"><br/><br/>
						<table align="center">
							<tr>
								<td><p><strong/>Nama: </p></td>
								<td><input type="text" name="nama" placeholder="Nama" required></td>
							</tr>
							<tr>
								<td><p><strong/>Usia: </p></td>
								<td><input type="number" min="0" name="usia" placeholder="0" required></td>
							</tr>
						</table><br/><br/><br/><br/>
					<p style="text-align:right;"><input type="submit" name="save" value="Mulai Diagnosis"/></p>
					</form>
				</div>
			  </div>
			  <div class="clr"></div>
			</div>
		  </div>
		  
		  <div class="fbg">
			<div class="fbg_resize">
			  <div class="col c1">
				<h2><span>Halaman</span></h2>
				<p>Diagnosis<br />
				  Jika Anda ingin melakukan pendiagnosaan, Anda dapat melakukannya sekarang juga di halaman <a href="diagnosis.php">Diagnosis</a>.</p>
				  <p>Tentang<br />
				  Jika Anda ingin mengetahui lebih lanjut tentang penyakit alopecia areata, sistem pakar, dan admin, silakan mengklik tautan <a href="tentang.php">Tentang</a>.</p></div>
			  <div class="col c2">
				<h2><span>Tentang</span></h2>
				<p>Informasi tentang penyakit alopecia areata, sistem pakar, dan admin dapat Anda klik di tautan:<br/>
				<a href="tentang.php#alopecia">Apa itu Alopecia Areata?</a><br/><a href="tentang.php#sistem">Apa itu Sistem Pakar?</a><br/><a href="tentang.php#TentangAdmin">Tentang Admin</a>.</p>
			  </div>
			  <div class="clr"></div>
			</div>
			<div class="footer">
			  <p class="lf">Copyright &copy; <a href="tentang.php#TentangAdmin">Fawwaz Mar'i Isa</a>. All Rights Reserved</p>
			  <div class="clr"></div>
			</div>
		  </div>
			
		</div>
	</body>
</html>
