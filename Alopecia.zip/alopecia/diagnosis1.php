<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Sistem Pakar | Diagnosis</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link href="style.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="js/cufon-yui.js"></script>
		<script type="text/javascript" src="js/arial.js"></script>
		<script type="text/javascript" src="js/cuf_run.js"></script>
		<?php include('koneksi.php');?>
		<style>
			input[type=submit]{
				font-family: calibri;
				font-size: 11pt;
				background: red;
				color: white;
				border: red 3px solid;
				border-radius: 5px;}
			a{text-decoration: none;}
			a:hover, input[type=submit]:hover {opacity:0.9;}
			table p{font-family:calibri;font-size:12pt; color:white;}
			.content .mainbar .article{
				margin:30px 70px 50px;
				width:550px;
				height:100%;
				background:url(images/dblue.png);}
			.qs p,label{color:white;font-family:calibri;font-size:14pt;}
			.qs input[type=submit]{
				font-family: calibri;
				font-size: 12pt;
				background: gray;
				color: white;
				border: gray 3px solid;
				border-radius: 5px;}
		</style>
	</head>
	
	<body>
		<div class="main">
		  
		  <div class="header">
			<div class="header_resize">
			  <div class="logo">
				<h1><a href="index.php"><span>Sistem Pakar</span>Alopecia Areata</a></h1>
			  </div>
			  <div class="menu_nav">
				<ul>
				  <li><a href="index.php"><span>Beranda</span></a></li>
				  <li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li>
				  <li class="active"><a href="diagnosis.php" style="color:red;"><span><strong/>Diagnosis</span></a></li>
				  <li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li>
				  <li><a href="tentang.php"><span>Tentang</span></a></li>
				</ul>
				<div class="clr"></div>
			  </div>			  
			  <div class="clr"></div>
			  <div class="header_img"><img src="images/medical-animation.png" alt="" width="300" height="125" />
				<h2>Lakukan <span>Diagnosis</span><br/> Sekarang!</h2>
				<p>Diagnosis berbasis web dapat menjadi alternatif pertama Anda sekarang juga!</p></div>
			</div>
		  </div>
		  
		  <div class="clr"></div>
		  <div class="content">
			<div class="content_resize">
			  <div class="mainbar">
				<div class="article">
				  <h2  align="center"><span>Pilih Jawaban Berdasarkan Gejala:</span></h2>
				  <div class="clr"></div>
					<div class="qs" align="center"><br/><br/><br/>
					<!--DISINI FORM-->
						<form action="hasildg.php" method="post">
						<!--1-->
						<?php
						$data = mysqli_query($koneksi,"select * from gejala where gid=1");
						while($d = mysqli_fetch_array($data)){
						?>
							<p><?php echo $d['gejala'];?></p>
							<img src="images/rontok.webp" width="540" height="179" alt=""/>
							<table>	
								<tr>
									<td><input type="radio" name="g01" value="90" required></td>
									<td><label for="y1"><?php echo $d['pil1'];?></label></td>
								</tr>
								<tr>
									<td><input type="radio" name="g01" value="0"></td>
									<td><label for="tdk1"><?php echo $d['pil2'];?></label></td>
								</tr>
						</table><br/><br/><?php } ?>
						<!--2-->
						<?php
						$data = mysqli_query($koneksi,"select * from gejala where gid=2");
						while($d = mysqli_fetch_array($data)){
						?>
							<p><?php echo $d['gejala'];?></p>
							<img src="images/manlops.webp" width="540" height="179" alt=""/>
							<table>	
								<tr>
									<td><input type="radio" name="g02" value="0" required></td>
									<td><label for="tdk2"><?php echo $d['pil1'];?></label></td>
								</tr>
								<tr>
									<td><input type="radio" name="g02" value="30"></td>
									<td><label for="sdkt2"><?php echo $d['pil2'];?></label></td>
								</tr>
								<tr>
									<td><input type="radio" name="g02" value="60"></td>
									<td><label for="lmyn2"><?php echo $d['pil3'];?></label></td>
								</tr>
								<tr>
									<td><input type="radio" name="g02" value="90"></td>
									<td><label for="sngt2"><?php echo $d['pil4'];?></label></td>
								</tr>
							</table><br/><br/><?php } ?>
						<!--3-->
						<?php
						$data = mysqli_query($koneksi,"select * from gejala where gid=3");
						while($d = mysqli_fetch_array($data)){
						?>
							<p><?php echo $d['gejala'];?></p>
							<img src="images/Capture.png" width="540" height="400" alt=""/>
							<table>	
							
								<tr>
									<td><input type="radio" name="g03" value="0" required></td>
									<td><label for="tdk3"><?php echo $d['pil5'];?></label></td>
								</tr>
								<tr>
									<td><input type="radio" name="g03" value="36" required></td>
									<td><label for="kri"><?php echo $d['pil1'];?></label></td>
								</tr>
								<tr>
									<td><input type="radio" name="g03" value="36"></td>
									<td><label for="knn"><?php echo $d['pil2'];?></label></td>
								</tr>
								<tr>
									<td><input type="radio" name="g03" value="48"></td>
									<td><label for="blkg"><?php echo $d['pil4'];?></label></td>
								</tr>
								<tr>
									<td><input type="radio" name="g03" value="80"></td>
									<td><label for="atas"><?php echo $d['pil3'];?></label></td>
								</tr>
							</table><br/><br/><?php } ?>
						<!--4-->
						<?php
						$data = mysqli_query($koneksi,"select * from gejala where gid=4");
						while($d = mysqli_fetch_array($data)){
						?>
							<p><?php echo $d['gejala'];?></p>
							<img src="images/ages.webp" width="550" height="200px" alt=""/>
							<table>	
								<tr>
									<td><input type="radio" name="g04" value="90" required></td>
									<td><label for="1st"><?php echo $d['pil1'];?></label></td>
								</tr>
								<tr>
									<td><input type="radio" name="g04" value="72"></td>
									<td><label for="2nd"><?php echo $d['pil2'];?></label></td>
								</tr>
								<tr>
									<td><input type="radio" name="g04" value="54"></td>
									<td><label for="3rd"><?php echo $d['pil3'];?></label></td>
								</tr>
								<tr>
									<td><input type="radio" name="g04" value="36"></td>
									<td><label for="4th"><?php echo $d['pil4'];?></label></td>
								</tr>
								<tr>
									<td><input type="radio" name="g04" value="18"></td>
									<td><label for="5th"><?php echo $d['pil5'];?></label></td>
								</tr>
							</table><br/><br/><?php } ?>
						<!--5-->
						<?php
						$data = mysqli_query($koneksi,"select * from gejala where gid=5");
						while($d = mysqli_fetch_array($data)){
						?>
							<p><?php echo $d['gejala'];?></p>
							<img src="images/kuku.jpg" width="540" height="200" alt=""/>
							<table>	
								<tr>
									<td><input type="radio" name="g05" value="0" required></td>
									<td><label for="tdk5"><?php echo $d['pil1'];?></label></td>
								</tr>
								<tr>
									<td><input type="radio" name="g05" value="20"></td>
									<td><label for="sdkt5"><?php echo $d['pil2'];?></label></td>
								</tr>
								<tr>
									<td><input type="radio" name="g05" value="40"></td>
									<td><label for="lmyn5"><?php echo $d['pil3'];?></label></td>
								</tr>
								<tr>
									<td><input type="radio" name="g05" value="60"></td>
									<td><label for="sngt5"><?php echo $d['pil4'];?></label></td>
								</tr>
							</table><br/><br/><?php } ?>
						<!--6-->
						<?php
						$data = mysqli_query($koneksi,"select * from gejala where gid=6");
						while($d = mysqli_fetch_array($data)){
						?>						
							<p><?php echo $d['gejala'];?></p>
							<img src="images/alox.jpg" width="540" height="180" alt=""/>
							<table>	
								<tr>
									<td><input type="radio" name="g06" value="20" required></td>
									<td><label for="y6"><?php echo $d['pil1'];?></label></td>
								</tr>
								<tr>
									<td><input type="radio" name="g06" value="0"></td>
									<td><label for="tdk6"><?php echo $d['pil2'];?></label></td>
								</tr>
							</table><br/><br/><?php } ?>
						<!--7-->
						<?php
						$data = mysqli_query($koneksi,"select * from gejala where gid=7");
						while($d = mysqli_fetch_array($data)){
						?>
							<p><?php echo $d['gejala'];?></p>
							<img src="images/autoimun.webp" width="550" height="200px" alt=""/>
							<table>	
								<tr>
									<td><input type="radio" name="g07" value="25" required></td>
									<td><label for="y7"><?php echo $d['pil1'];?></label></td>
								</tr>
								<tr>
									<td><input type="radio" name="g07" value="0"></td>
									<td><label for="tdk7"><?php echo $d['pil2'];?></label></td>
								</tr>
							</table><br/><br/><?php } ?>
						<!--8-->
						<?php
						$data = mysqli_query($koneksi,"select * from gejala where gid=8");
						while($d = mysqli_fetch_array($data)){
						?>
							<p><?php echo $d['gejala'];?></p>
							<img src="images/down.jpg" width="500" height="400px" alt=""/>
							<table>	
								<tr>
									<td><input type="radio" name="g08" value="30" required></td>
									<td><label for="y8"><?php echo $d['pil1'];?></label></td>
								</tr>
								<tr>
									<td><input type="radio" name="g08" value="0"></td>
									<td><label for="tdk8"><?php echo $d['pil2'];?></label></td>
								</tr>
							</table><br/><br/><?php } ?>
						<!--9-->
						<?php
						$data = mysqli_query($koneksi,"select * from gejala where gid=9");
						while($d = mysqli_fetch_array($data)){
						?>
							<p><?php echo $d['gejala'];?></p>
							<img src="images/depress.png" width="550" height="200px" alt=""/>
							<table>	
								<tr>
									<td><input type="radio" name="g09" value="25" required></td>
									<td><label for="y9"><?php echo $d['pil1'];?></label></td>
								</tr>
								<tr>
									<td><input type="radio" name="g09" value="0"></td>
									<td><label for="tdk9"><?php echo $d['pil2'];?></label></td>
								</tr>
							</table><br/><br/><?php } ?>
						<!--10-->
						<?php
						$data = mysqli_query($koneksi,"select * from gejala where gid=10");
						while($d = mysqli_fetch_array($data)){
						?>
							<p><?php echo $d['gejala'];?></p>
							<img src="images/asma.jpg" width="550" height="200px" alt=""/>
							<table>	
								<tr>
									<td><input type="radio" name="g10" value="30" required></td>
									<td><label for="y10"><?php echo $d['pil1'];?></label></td>
								</tr>
								<tr>
									<td><input type="radio" name="g10" value="0"></td>
									<td><label for="tdk10"><?php echo $d['pil2'];?></label></td>
								</tr>
							</table><br/><br/><?php } ?>
						<!--11-->
						<?php
						$data = mysqli_query($koneksi,"select * from gejala where gid=11");
						while($d = mysqli_fetch_array($data)){
						?>
							<p><?php echo $d['gejala'];?></p>
							<img src="images/rinitis.jpg" width="550" height="200px" alt=""/>
							<table>	
								<tr>
									<td><input type="radio" name="g11" value="30" required></td>
									<td><label for="y11"><?php echo $d['pil1'];?></label></td>
								</tr>
								<tr>
									<td><input type="radio" name="g11" value="0"></td>
									<td><label for="tdk11"><?php echo $d['pil2'];?></label></td>
								</tr>
							</table><br/><br/><?php } ?>
						<!--12-->
						<?php
						$data = mysqli_query($koneksi,"select * from gejala where gid=12");
						while($d = mysqli_fetch_array($data)){
						?>
							<p><?php echo $d['gejala'];?></p>
							<img src="images/dermatitis.jpg" width="550" height="200px" alt=""/>
							<table>	
								<tr>
									<td><input type="radio" name="g12" value="30" required></td>
									<td><label for="y12"><?php echo $d['pil1'];?></label></td>
								</tr>
								<tr>
									<td><input type="radio" name="g12" value="0"></td>
									<td><label for="tdk12"><?php echo $d['pil2'];?></label></td>
								</tr>	
							</table><br/><br/><?php } ?>
						<?php
						
						$nama = $_POST['nama'];
						$usia = $_POST['usia'];
						if(isset($_POST['save'])){
							$sql = "INSERT INTO user (id,nama,usia)
							VALUES ('','$nama','$usia')";
							$result = mysqli_query($koneksi,$sql);
						}
						?>
							<p style="text-align:right;"><input type="submit" name="save" value="Selanjutnya"/></p>
							</form>
					</div>
				</div>
			  </div>
			  <div class="clr"></div>
			</div>
		  </div>
		  
		  <div class="fbg">
			<div class="fbg_resize">
			  <div class="col c1">
				<h2><span>Halaman</span></h2>
				<p>Diagnosis<br />
				  Jika Anda ingin melakukan pendiagnosaan, Anda dapat melakukannya sekarang juga di halaman <a href="diagnosis.html">Diagnosis</a>.</p>
				  <p>Tentang<br />
				  Jika Anda ingin mengetahui lebih lanjut tentang penyakit alopecia areata, sistem pakar, dan admin, silakan mengklik tautan <a href="tentang.php">Tentang</a>.</p></div>
			  <div class="col c2">
				<h2><span>Tentang</span></h2>
				<p>Informasi tentang penyakit alopecia areata, sistem pakar, dan admin dapat Anda klik di tautan:<br/>
				<a href="tentang.php#alopecia">Apa itu Alopecia Areata?</a><br/><a href="tentang.php#sistem">Apa itu Sistem Pakar?</a><br/><a href="tentang.php#TentangAdmin">Tentang Admin</a>.</p>
			  </div>
			  <div class="clr"></div>
			</div>
			<div class="footer">
			  <p class="lf">Copyright &copy; <a href="tentang.php#TentangAdmin">Fawwaz Mar'i Isa</a>. All Rights Reserved</p>
			  <div class="clr"></div>
			</div>
		  </div>
			
		</div>
		
	<script src="js/wow.min.js"></script>
        <script>
        new WOW().init();
        </script>
	</body>

</html>
