<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Sistem Pakar | Diagnosis</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link href="style.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="js/cufon-yui.js"></script>
		<script type="text/javascript" src="js/arial.js"></script>
		<script type="text/javascript" src="js/cuf_run.js"></script>
		<?php include('koneksi.php');?>
		<style>
			table p{font-family:calibri;font-size:12pt; color:white;}
			a{text-decoration: none;}
			a:hover {opacity:0.9;}
			.content .mainbar .article{
				margin:30px 150px 50px;
				width:350px;
				height:350px;
				background:url(images/dblue.png);}
		</style>
	</head>
	
	<body>
		<div class="main">
		  
		  <div class="header">
			<div class="header_resize">
			  <div class="logo">
				<h1><a href="index.php"><span>Sistem Pakar</span>Alopecia Areata</a></h1>
			  </div>
			  <div class="menu_nav">
				<ul>
				  <li><a href="index.php"><span>Beranda</span></a></li>
				  <li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li>
				  <li class="active"><a href="diagnosis.php" style="color:red;"><span><strong/>Diagnosis</span></a></li>
				  <li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li>
				  <li><a href="tentang.php"><span>Tentang</span></a></li>
				</ul>
				<div class="clr"></div>
			  </div>			  
			  <div class="clr"></div>
			  <div class="header_img"><img src="images/medical-animation.png" alt="" width="300" height="125" />
				<h2>Lakukan <span>Diagnosis</span><br/> Sekarang!</h2>
				<p>Diagnosis berbasis web dapat menjadi alternatif pertama Anda sekarang juga!</p></div>
			</div>
		  </div>
		  
		  <div class="clr"></div>
		  <div class="content">
			<div class="content_resize">
			  <div class="mainbar">
				<div class="article">
				  <h2  align="center"><span>Hasil</span> Diagnosis</h2><br>
				  <div class="clr"></div>
					<!--DISINI FORM-->
						<table>
						<?php
						$d1 = $_POST['g01'];
						$d2 = $_POST['g02'];
						$d3 = $_POST['g03'];
						$d4 = $_POST['g04'];
						$d5 = $_POST['g05'];
						$d6 = $_POST['g06'];
						$d7 = $_POST['g07'];
						$d8 = $_POST['g08'];
						$d9 = $_POST['g09'];
						$d10 = $_POST['g10'];
						$d11 = $_POST['g11'];
						$d12 = $_POST['g12'];
						$hasil=($d1+$d2+$d3+$d4+$d5+$d6+$d7+$d8+$d9+$d10+$d11+$d12)/12;
						$htg=$hasil/50*100;
						$per=round($htg, 0);
						if($hasil >= 17 && $hasil<=50  ){
						$hasil1 = "<strong>Terdeteksi $per% Alopecia Areata.</strong><br> Anda disarankan melakukan pengecekan lebih lanjut dengan Dokter Spesialis Kulit.";
						} else{
						$hasil1 = "Anda Tidak Terdeteksi Alopecia Areata";
						}
						$data = mysqli_query($koneksi,"select * from user order by id desc limit 1");
						while($d = mysqli_fetch_array($data)){
						?>
							<tr>
								<td><p>Nama: </p></td>
								<td><p><strong/><?php echo $d['nama']; ?></p></td>
							</tr>
							<tr>
								<td><p>Usia: </p></td>
								<td><p><strong/><?php echo $d['usia']; ?></p></td>
							</tr>
							<tr>
								<td><p>Hasil: </p></td>
								<td><p><?php echo $hasil1; ?></p></td>
							</tr>
							<tr>
								<td></td>
								<td><p><a href="tentang.php" style="color:#00dcff;">Baca Lebih lanjut...</a></p></td>
							</tr>
						<?php }
						$sql="UPDATE user SET g01='$d1',g02='$d2',g03='$d3',g04='$d4',g05='$d5',g06='$d6',g07='$d7',g08='$d8',g09='$d9',g10='$d10',g11='$d11',g12='$d12',hasil='$hasil' order by id desc limit 1";
						$result = mysqli_query($koneksi,$sql);
						?>
						</table><br/><br/><br/><br/>
				</div>
			  </div>
			  <div class="clr"></div>
			</div>
		  </div>
		  
		  <div class="fbg">
			<div class="fbg_resize">
			  <div class="col c1">
				<h2><span>Halaman</span></h2>
				<p>Diagnosis<br />
				  Jika Anda ingin melakukan pendiagnosaan, Anda dapat melakukannya sekarang juga di halaman <a href="diagnosis.php">Diagnosis</a>.</p>
				  <p>Tentang<br />
				  Jika Anda ingin mengetahui lebih lanjut tentang penyakit alopecia areata, sistem pakar, dan admin, silakan mengklik tautan <a href="tentang.php">Tentang</a>.</p></div>
			  <div class="col c2">
				<h2><span>Tentang</span></h2>
				<p>Informasi tentang penyakit alopecia areata, sistem pakar, dan admin dapat Anda klik di tautan:<br/>
				<a href="tentang.php#alopecia">Apa itu Alopecia Areata?</a><br/><a href="tentang.php#sistem">Apa itu Sistem Pakar?</a><br/><a href="tentang.php#TentangAdmin">Tentang Admin</a>.</p>
			  </div>
			  <div class="clr"></div>
			</div>
			<div class="footer">
			  <p class="lf">Copyright &copy; <a href="tentang.php#TentangAdmin">Fawwaz Mar'i Isa</a>. All Rights Reserved</p>
			  <div class="clr"></div>
			</div>
		  </div>
			
		</div>
	</body>
</html>
