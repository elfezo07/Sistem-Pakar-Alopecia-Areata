<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Sistem Pakar | Tentang</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link href="style.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<script type="text/javascript" src="js/cufon-yui.js"></script>
		<script type="text/javascript" src="js/arial.js"></script>
		<script type="text/javascript" src="js/cuf_run.js"></script>
		<style>
			.dropbtn {
			  border: none;
			  cursor: pointer;
			}
			.dropbtn:hover, .dropbtn:focus {
			  background-color: #2980B9;
			}
			.dropdown-content {
			  display: none;
			  position: static;
			  z-index: 1;
			}
			.show {display:block;}
			.konten p{font-family:calibri;font-size:11pt;}
		</style>
	</head>
	
	<body>
		<div class="main">
		  
		  <div class="header">
			<div class="header_resize">
			  <div class="logo">
				<h1><a href="index.php"><span>Sistem Pakar</span>Alopecia Areata</a></h1>
			  </div>
			  <div class="menu_nav">
				<ul>
				  <li><a href="index.php"><span>Beranda</span></a></li>
				  <li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li>
				  <li><a href="diagnosis.php" style="color:red;"><span><strong/>Diagnosis</span></a></li>
				  <li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li><li><a/></li>
				  <li class="active"><a href="tentang.php"><span>Tentang</span></a></li>
				</ul>
				<div class="clr"></div>
			  </div>
			  <div class="clr"></div>
			  <div class="header_img"><img src="images/medical-animation.png" alt="" width="300" height="125" />
				<h2>Lakukan <span>Diagnosis</span><br/> Sekarang!</h2>
				<p>Diagnosis berbasis web dapat menjadi alternatif pertama Anda sekarang juga!</p>
			  </div>
			</div>
		  </div>
		  
		  <div class="clr"></div>
		  <div class="content">
			<div class="content_resize">
			  <div class="mainbar">
				
				<div class="article" align="justify">
					<h2 id="alopecia"><span>Apa itu</span> Alopecia Areata?</h2>
					<button onclick="myFunction()" class="dropbtn"><i class="fa fa-caret-down"></i></button>
					  <div class="clr"></div>
					  <div id="alop" class="dropdown-content">
					   <div class="konten">
						  <img src="images/alopecia.png" width="613" height="179" alt=""/><p><strong>Alopecia areata adalah kebotakan atau kerontokan rambut yang disebabkan oleh penyakit autoimun. Pada alopecia areata, sistem imun menyerang dan merusak folikel rambut, sehingga menyebabkan kerontokan dan kebotakan. Kulit kepala botak dengan bentuk pitak adalah salah satu tanda dari kondisi ini.</strong></p>
						  <p>Alopecia merupakan kondisi terjadinya kerontokan rambut yang tidak normal. Penyakit ini menyerang tempat di mana rambut akan tumbuh, bahkan hingga dapat menghentikan proses pertumbuhan rambut. Secara umum alopecia areata merupakan kondisi yang tidak berbahaya. Alopecia areata bisa diderita oleh laki-laki atau perempuan. Umumnya, alopecia areata terjadi sebelum penderitanya berusia 30 tahun. Kondisi ini paling sering memengaruhi rambut yang ada di kulit kepala.</p>
						  <p><strong>Penyebab Alopecia Areata</strong><br/>
						  Alopecia areata disebabkan oleh sistem imun yang menyerang folikel rambut (penyakit autoimun). Kondisi ini menyebabkan keluarnya sitokin proinflamasi dan kemokin. Hal inilah yang kemudian menyebabkan terhentinya produksi rambut. Akibatnya, rambut menjadi rontok dan akhirnya menjadi botak.<br/>Hingga saat ini belum diketahui penyebab pasti mengapa sistem imun menyerang dan merusak folikel rambut. Akan tetapi, kondisi ini diduga dipicu oleh infeksi virus, trauma, perubahan hormon, serta stres fisik atau psikis.</p>
						  <p><strong>Gejala Alopecia Areata</strong><br/>
						  Gejala umum: rambut rontok, gatal, kegelisahan atau lekukan kecil di kuku.<br/>
						  Gejala spesifik:<br/>• Kebotakan berpola bulat atau seperti pitak yang muncul di satu atau beberapa tempat yang tadinya ditumbuhi rambut.<br/>• Kebotakan terjadi pada bagian bawah, samping, atau melingkari belakang kepala (ophiasis alopecia).</p>
						  <p>Selain menyebabkan terbentuknya botak pitak pada kulit kepala, alopecia juga memiliki tipe lain, yaitu jika kebotakan terjadi satu area secara menyeluruh, maka kondisi ini disebut juga alopecia areata totalis. Sedangkan jika terjadi pada semua area tubuh yang berambut, maka kondisinya disebut alopecia areata universalis. Umumnya, rambut yang rontok pada penderita alopecia areata bisa tumbuh kembali dengan sendirinya. Namun, pada sebagian penderita alopecia areata, kebotakan bisa menjadi permanen. Ini berarti rambut tidak tumbuh kembali. Kuku penderita alopecia areata juga sering mengalami perubahan, antara lain kuku tampak kemerahan, berlekuk, atau menjadi terasa kasar dan tipis, sehingga mudah terbelah.</p>
						  <p><strong>Pencegahan Alopecia Areata</strong><br/>
						  Alopecia areata sulit untuk dicegah karena belum diketahui penyebab pastinya. Namun, menghilangkan stres diyakini dapat membantu dalam mencegah terjadinya alopecia areata. Beberapa cara di bawah ini dapat Anda lakukan untuk meredakan stres:<br/>
						  • Melakukan latihan pernapasan atau melakukan meditasi.<br/>
						  • Mengurangi konsumsi minuman yang mengandung kafein.<br/>
						  • Mendengarkan musik yang menenangkan.<br/>
						  • Melakukan hal atau hobi yang menyenangkan.<br/>
						  • Menyediakan waktu untuk bersosialisasi dengan keluarga dan teman atau bermain dengan binatang peliharaan.</p>
						  <p><strong>Kapan harus ke dokter</strong><br/>
						  Lakukanlah pemeriksaan ke dokter jika Anda mengalami kebotakan atau kerontokan rambut yang tidak biasa. Deteksi dini dapat membantu Anda mengetahui penyebab kerontokan rambut yang dialami, sehingga bisa dilakukan penanganan yang sesuai dengan penyebab dan kondisi yang Anda alami.
						  <p><strong>Alternatif</strong><br/>
						  Walaupun tidak berbahaya terkadang alopecia areata dapat mengakibatkan ketidaknyamanan akibat kebotakan yang dialami. Berikut beberapa cara yang dapat dilakukan untuk mengatasi ketidaknyaman yang dirasakan:<br/>
						  • Meminta obat untuk merangsang pertumbuhan rambut kepada dokter rujukan.<br/>
						  • Menggunakan rambut palsu, topi, dan mengoleskan krim tabir surya pada bagian yang botak, untuk melindungi kulit dari sinar matahari.<br/>
						  • Mencukur rambut kepala, kumis, atau jenggot agar kebotakan terlihat merata.<br/>
						  • Menggunakan kacamata atau bulu mata palsu, untuk melindungi mata dari debu jika menderita kebotakan pada alis dan bulu mata.<br/></div>
					  </div>		  
				</div>
				
				<div class="article" align="justify">
				  <h2 id="sistem"><span>Apa itu</span> Sistem Pakar?</h2>
				  <button onclick="miFunction()" class="dropbtn"><i class="fa fa-caret-down"></i></button>
					<div class="clr"></div>
					<div id="sp" class="dropdown-content">
					<div class="konten">
					<img src="images/expertsystem.jpg" width="613" height="179" alt=""/>
					  <p><strong>Sistem pakar adalah suatu sistem komputer yang bisa meniru kemampuan seorang pakar. Pakar yang dimaksud disini ialah orang yang mempunyai keahlian khusus yang dapat menyelesaikan masalah yang tidak dapat diselesaikan orang awam.</strong></p>
					  <p><strong>Tujuan Sistem Pakar</strong></br>
					  Sistem pakar dapat membantu aktivitas para pakar sebagai asisten yang berpengalaman dan mempunyai pengetahuan yang dibutuhkan. Dengan sistem pakar ini, orang awam pun dapat menyelesaikan masalahnya atau hanya sekedar mencari suatu informasi berkualitas yang sebenarnya hanya dapat diperoleh dengan bantuan para ahli di bidangnya.</p>
					  <p><strong>Ciri-Ciri Sistem Pakar</strong><br/>
						Sistem pakar memenuhi ciri-ciri sebagai berikut:<br/>
						• Memiliki informasi yang handal.<br/>
						• Mudah dimodifikasi.<br/>
						• Dapat digunakan dalam berbagai jenis komputer.<br/>
						• Memiliki kemampuan untuk belajar beradaptasi.</p>
					  <p><strong>Pengembangan Sistem Pakar</strong><br/>
					  Sistem Pakar sendiri dikembangkan berdasarkan alasan yang meliputi:<br/>
						• Dapat menyediakan kepakaran setiap waktu dan di berbagai lokasi.<br/>
						• Secara otomatis mengerjakan tugas-tugas rutin yang membutuhkan seorang pakar.<br/>
						• Seorang pakar sedang tidak tersedia.<br/>
						• Kepakaran dibutuhkan juga pada lingkungan yang tidak bersahabat.</p></div>
					</div>
				</div>
				
				<div class="article">
				  <h2 id="TentangAdmin"><span>Tentang</span> Admin</h2>
				  <button onclick="mine()" class="dropbtn"><i class="fa fa-caret-down"></i></button>
					<div class="clr"></div>
					<div id="mi" class="dropdown-content">
					  <br/><img src="images/grayg.jpg"/><p align="center"><strong><br/>Profil Admin</strong></p>
					</div>
				</div>
				
			  </div>
			  <div class="clr"></div>
			</div>
		  </div>
		  <br/><br/><br/>
		  <div class="fbg">
			<div class="fbg_resize">
			  <div class="col c1">
				<h2><span>Halaman</span></h2>
				<p>Diagnosis<br/>
				  Jika Anda ingin melakukan pendiagnosaan, Anda dapat melakukannya sekarang juga di halaman <a href="diagnosis.php">Diagnosis</a>.</p>
				  <p>Tentang<br/>
				  Jika Anda ingin mengetahui lebih lanjut tentang penyakit alopecia areata, sistem pakar, dan admin, silakan mengklik tautan <a href="tentang.php">Tentang</a>.</p></div>
			  <div class="col c2">
				<h2><span>Tentang</span></h2>
				<p>Informasi tentang penyakit alopecia areata, sistem pakar, dan admin dapat Anda klik di tautan:<br/>
				<a href="tentang.php#alopecia">Apa itu Alopecia Areata?</a><br/><a href="tentang.php#sistem">Apa itu Sistem Pakar?</a><br/><a href="tentang.php#TentangAdmin">Tentang Admin</a>.</p>
			  </div>
			  <div class="clr"></div>
			</div>
			<div class="footer">
			  <p class="lf">Copyright &copy; <a href="tentang.php#TentangAdmin">Fawwaz Mar'i Isa</a>. All Rights Reserved</p>
			  <div class="clr"></div>
			</div>
		  </div>
		  
		</div>		
	</body>
		
	<script>
		/* When the user clicks on the button,
		toggle between hiding and showing the dropdown content */
		function myFunction() {
		  document.getElementById("alop").classList.toggle("show");
		}
		function miFunction() {
		  document.getElementById("sp").classList.toggle("show");
		}
		function mine() {
		  document.getElementById("mi").classList.toggle("show");
		}
		
		// Close the dropdown menu if the user clicks outside of it
		window.onclick = function(event) {
		  if (!event.target.matches('.dropbtn')) {
			var dropdowns = document.getElementsByClassName("dropdown-content");
			var i;
			for (i = 0; i < dropdowns.length; i++) {
			  var openDropdown = dropdowns[i];
			  if (openDropdown.classList.contains('show')) {
				openDropdown.classList.remove('show');
			  }
			}
		  }
		}
	</script>	
</html>
